<?php

class GerarModel
{
    private $causas = [
    "o computador apresentou um erro inesperado enquanto eu estava trabalhando",
    "o arquivo começou a apresentar problemas depois que eu fiz uma alteração",
    "a internet caiu justamente quando eu estava enviando o trabalho",
    "o programa começou a travar toda vez que eu tentava salvar o arquivo",
    "o computador decidiu instalar uma atualização no pior momento possível",
    "o arquivo ficou corrompido depois que o programa fechou sozinho",
    "o sistema apresentou um erro que não tinha aparecido nenhuma vez antes",
    "o trabalho estava funcionando normalmente até eu tentar fazer a última alteração",
    "o computador começou a ficar extremamente lento sem nenhuma explicação",
    "o programa parou de responder quando eu estava terminando o trabalho",
    "a conexão ficou instável e o arquivo não conseguiu ser salvo corretamente",
    "o sistema identificou um problema justamente quando eu estava finalizando tudo"
];

private $consequencias = [
    "por causa disso, perdi uma parte do trabalho que ainda não tinha sido salva",
    "por isso, precisei refazer uma parte que já estava pronta",
    "e isso acabou atrasando todo o restante do trabalho",
    "como o arquivo não abriu mais, precisei tentar recuperar uma versão anterior",
    "isso fez com que eu gastasse muito mais tempo tentando descobrir o que tinha acontecido",
    "e consequentemente não consegui terminar dentro do prazo esperado",
    "por causa desse problema, precisei reiniciar o computador e começar aquela parte novamente",
    "isso acabou comprometendo o restante do trabalho porque tudo dependia daquela parte",
    "e quando finalmente consegui resolver, já não havia tempo suficiente para terminar tudo",
    "por causa disso, precisei procurar uma forma alternativa de fazer a mesma tarefa",
    "o problema parecia simples no começo, mas acabou afetando várias outras partes do trabalho",
    "e isso fez com que o tempo que eu tinha planejado para terminar o trabalho acabasse"
];

private $solucoes = [
    "agora vou precisar refazer essa parte e conferir tudo antes de tentar enviar novamente",
    "a melhor opção será corrigir o problema e finalizar o trabalho assim que possível",
    "vou tentar recuperar a versão anterior e reconstruir o que foi perdido",
    "será necessário revisar o arquivo inteiro para garantir que o problema não aconteça novamente",
    "vou precisar terminar essa parte novamente antes de conseguir entregar o trabalho",
    "a solução será testar o programa novamente e corrigir o erro antes de continuar",
    "vou refazer a parte afetada e salvar várias cópias para evitar que isso aconteça novamente",
    "agora preciso verificar exatamente onde o problema começou antes de conseguir finalizar",
    "vou tentar resolver o problema de outra maneira e terminar o trabalho dessa forma",
    "será necessário mais um tempo para corrigir o problema e deixar tudo funcionando corretamente",
    "vou recuperar o máximo possível do trabalho e reconstruir o restante",
    "a ideia agora é corrigir o erro, testar tudo novamente e finalmente concluir o trabalho"
];

    public function gerarCausa()
    {
        return $this->causas[array_rand($this->causas)];
    }

    public function gerarConsequencia()
    {
        return $this->consequencias[array_rand($this->consequencias)];
    }

    public function gerarSolucao()
    {
        return $this->solucoes[array_rand($this->solucoes)];
    }

    public function gerarFrase($assunto)
    {
        return [
            "causa" => $this->gerarCausa(),
            "consequencia" => $this->gerarConsequencia(),
            "solucao" => $this->gerarSolucao()
        ];
    }
}